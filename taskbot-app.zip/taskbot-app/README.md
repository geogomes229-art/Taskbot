# TaskBot - Sala do Futuro & CMSP

Automatizador de atividades da Sala do Futuro e CMSP.

## Como publicar na Vercel

### Passo 1 — Criar repositório no GitHub

1. Acesse [github.com/new](https://github.com/new)
2. Nome do repositório: `taskbot-saladofuturo`
3. Clique em **Create repository**
4. Na próxima tela, clique em **"uploading an existing file"**
5. Arraste todos os arquivos desta pasta para lá
6. Clique em **Commit changes**

### Passo 2 — Publicar na Vercel

1. Acesse [vercel.com/new](https://vercel.com/new)
2. Clique em **"Import"** ao lado do repositório `taskbot-saladofuturo`
3. Clique em **Deploy**
4. Aguarde ~1 minuto — pronto! ✅

Seu app estará disponível em: `taskbot-saladofuturo.vercel.app`

## Estrutura

```
taskbot-app/
├── public/
│   └── index.html      # Interface do app
├── api/
│   ├── proxy.js        # Proxy para chamadas às APIs da Seduc
│   └── complete.js     # Endpoint que conclui as atividades
├── vercel.json         # Configuração da Vercel
└── package.json
```

## Funcionalidades

- ✅ Login com RA e senha
- ✅ Listar atividades pendentes
- ✅ Listar atividades expiradas
- ✅ Selecionar quais atividades concluir
- ✅ Escolher nota alvo (50–100)
- ✅ Concluir automaticamente
- ✅ Log de status em tempo real
