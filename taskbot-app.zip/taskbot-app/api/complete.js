export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { x_auth_key, room_code, lesson_id, draft, lesson_info, time_spent, answer_id, target_score } = req.body;

  if (!x_auth_key || !room_code || !lesson_id) {
    return res.status(400).json({ status: 'error', message: 'Parâmetros obrigatórios ausentes' });
  }

  try {
    // Build the answer payload based on lesson_info
    const payload = buildPayload(lesson_info, target_score);

    let apiRes;

    if (draft || !answer_id) {
      // Create new answer (draft)
      apiRes = await fetch(
        `https://edusp-api.ip.tv/tms/task/${lesson_id}/answer/?room_code=${room_code}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': x_auth_key,
          },
          body: JSON.stringify({
            ...payload,
            time_spent,
            finished: true,
          }),
        }
      );
    } else {
      // Update existing answer
      apiRes = await fetch(
        `https://edusp-api.ip.tv/tms/task/${lesson_id}/answer/${answer_id}/?room_code=${room_code}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': x_auth_key,
          },
          body: JSON.stringify({
            ...payload,
            time_spent,
            finished: true,
          }),
        }
      );
    }

    if (!apiRes.ok) {
      const errText = await apiRes.text();
      return res.status(200).json({ status: 'error', message: `API retornou ${apiRes.status}: ${errText.slice(0, 200)}` });
    }

    const data = await apiRes.json();
    return res.status(200).json({ status: 'success', data });

  } catch (err) {
    return res.status(200).json({ status: 'error', message: err.message });
  }
}

function buildPayload(lessonInfo, targetScore) {
  if (!lessonInfo || !lessonInfo.apply) return { answers: [] };

  const answers = [];

  (lessonInfo.apply.questions || []).forEach(q => {
    if (q.question_type === 'multiple_choice' || q.question_type === 'single_choice') {
      // Pick answers that get us to targetScore
      const choices = q.choices || [];
      // Try to pick correct ones if available
      const correct = choices.filter(c => c.is_correct);
      const selected = correct.length > 0 ? correct : [choices[0]].filter(Boolean);
      answers.push({
        question_id: q.id,
        choice_ids: selected.map(c => c.id),
      });
    } else if (q.question_type === 'true_false') {
      const correct = (q.choices || []).find(c => c.is_correct);
      if (correct) answers.push({ question_id: q.id, choice_ids: [correct.id] });
    }
    // Skip essay/open questions
  });

  return { answers };
}
