export default async function handler(req, res) {
  // Allow CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,x-api-key,X-Api-Key,ocp-apim-subscription-key,Accept,Accept-Language');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const targetUrl = req.query.url;
  if (!targetUrl) return res.status(400).json({ error: 'Missing url parameter' });

  // Whitelist allowed domains
  const allowed = [
    'https://edusp-api.ip.tv',
    'https://sedintegracoes.educacao.sp.gov.br',
  ];
  if (!allowed.some(a => targetUrl.startsWith(a))) {
    return res.status(403).json({ error: 'URL not allowed' });
  }

  try {
    const fetchOptions = {
      method: req.method === 'GET' ? 'GET' : req.method,
      headers: {},
    };

    // Forward relevant headers
    const forwardHeaders = [
      'content-type','accept','accept-language',
      'x-api-key','X-Api-Key',
      'ocp-apim-subscription-key',
    ];
    forwardHeaders.forEach(h => {
      const val = req.headers[h.toLowerCase()];
      if (val) fetchOptions.headers[h] = val;
    });

    if (req.method !== 'GET' && req.body) {
      fetchOptions.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
      if (!fetchOptions.headers['content-type']) {
        fetchOptions.headers['content-type'] = 'application/json';
      }
    }

    const response = await fetch(targetUrl, fetchOptions);
    const contentType = response.headers.get('content-type') || 'application/json';
    const data = await response.text();

    res.status(response.status)
       .setHeader('Content-Type', contentType)
       .send(data);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
